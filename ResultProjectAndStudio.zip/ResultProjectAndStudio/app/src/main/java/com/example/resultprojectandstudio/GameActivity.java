package com.example.resultprojectandstudio;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class GameActivity extends AppCompatActivity {

    private TextView questionText;
    private ImageView akinatorImage;
    private Map<String, String> traitScores = new HashMap<>();
    private int dontKnowValue = 0;
    private int currentSpriteIndex = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        questionText = findViewById(R.id.questionText);
        akinatorImage = findViewById(R.id.akinatorImage);

        Button btnYes = findViewById(R.id.btnYes);
        Button btnProbably = findViewById(R.id.btnProbably);
        Button btnIDontKnow = findViewById(R.id.btnIDontKnow);
        Button btnProbablyNot = findViewById(R.id.btnProbablyNot);
        Button btnNo = findViewById(R.id.btnNo);
        ImageView refreshIcon = findViewById(R.id.refreshIcon);
        refreshIcon.setOnClickListener(v -> {
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        });

        traitScores.put("dontKnowValue", "0");

        Random rand = new Random();
        currentSpriteIndex = rand.nextInt(8) + 1;
        int resId = getResources().getIdentifier("akinator_" + currentSpriteIndex, "drawable", getPackageName());
        akinatorImage.setImageResource(resId);

        proceedTheGame();

        btnYes.setOnClickListener(v -> handleAnswer("1"));
        btnProbably.setOnClickListener(v -> handleAnswer("1"));
        btnIDontKnow.setOnClickListener(v -> {
            dontKnowValue++;
            traitScores.put("dontKnowValue", String.valueOf(dontKnowValue));
            proceedTheGame();
        });
        btnProbablyNot.setOnClickListener(v -> handleAnswer("0"));
        btnNo.setOnClickListener(v -> handleAnswer("0"));
    }

    private void handleAnswer(String score) {
        new TraitByQuestionTask(questionText.getText().toString(), score).execute();
    }

    private void proceedTheGame() {
        new FetchBestTraitTask().execute();
    }

    private void toResults(String message) {
        Intent intent = new Intent(GameActivity.this, ResultActivity.class);
        intent.putExtra("show_loose", true);
        intent.putExtra("top_message", message);
        startActivity(intent);

        new Handler().postDelayed(() -> {
            Intent restartIntent = new Intent(GameActivity.this, GameActivity.class);
            startActivity(restartIntent);
            finish();
        }, 5000);
    }

    private void handleErrors(String error) {
        switch (error) {
            case "Мы не знаем героев которые подходят под описание...":
                toResults("Я не знаю персонажей, подходящих твоему описанию...");
                break;
            case "No traits left to analyze":
                toResults("Я спросил всё, что мог, но всё ещё не знаю, кого ты загадал...");
                break;
            case "No traits left to analyze after skipping":
                toResults("Вы вообще ничего не знаете о своём герое... Пожалуйста, загадайте другого!");
                break;
            default:
                toResults(error);
                break;
        }
    }


    private class FetchBestTraitTask extends AsyncTask<Void, Void, JSONObject> {
        @Override
        protected JSONObject doInBackground(Void... voids) {
            try {
                StringBuilder query = new StringBuilder();
                for (Map.Entry<String, String> entry : traitScores.entrySet()) {
                    query.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
                }
                if (query.length() > 0) {
                    query.setLength(query.length() - 1);
                }
                URL url = new URL("https://app-a2989357-1f55-4709-adfc-df0a25cdbbd8.cleverapps.io/fetch_least_trait.php?" + query);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Accept", "application/json");

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();

                return new JSONObject(response.toString());

            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(JSONObject response) {
            if (response == null) {
                handleErrors("Ошибка соединения с сервером.");
                return;
            }

            if (response.has("id")) {
                try {
                    int id = response.getInt("id");
                    Intent intent = new Intent(GameActivity.this, ResultActivity.class);
                    intent.putExtra("hero_id", id);
                    startActivity(intent);
                    finish();
                } catch (Exception e) {
                    handleErrors("Ошибка обработки героя.");
                }
            } else if (response.has("trait")) {
                try {
                    String trait = response.getString("trait");
                    new FetchQuestionTask(trait).execute();
                } catch (Exception e) {
                    handleErrors("Ошибка получения вопроса.");
                }
            } else if (response.has("error")) {
                handleErrors(response.optString("error"));
            } else {
                handleErrors("Неизвестная ошибка.");
            }
        }
    }

    private class FetchQuestionTask extends AsyncTask<Void, Void, String> {
        private final String trait;

        FetchQuestionTask(String trait) {
            this.trait = trait;
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL("https://app-a2989357-1f55-4709-adfc-df0a25cdbbd8.cleverapps.io/question.php?trait=" + trait);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Accept", "application/json");

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();

                JSONObject json = new JSONObject(response.toString());
                return json.getString("question");
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(String question) {
            if (question != null) {
                questionText.setText(question);
            } else {
                handleErrors("Ошибка загрузки вопроса.");
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class TraitByQuestionTask extends AsyncTask<Void, Void, String> {
        private final String question;
        private final String score;

        TraitByQuestionTask(String question, String score) {
            this.question = question;
            this.score = score;
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL("https://app-a2989357-1f55-4709-adfc-df0a25cdbbd8.cleverapps.io/trait_by_question.php?question=" + question);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Accept", "application/json");

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();

                JSONObject json = new JSONObject(response.toString());
                return json.getString("trait");
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(String trait) {
            if (trait != null) {
                traitScores.put(trait, score);
                dontKnowValue = 0;
                traitScores.put("dontKnowValue", "0");
                proceedTheGame();
            } else {
                handleErrors("Ошибка определения трейта.");
            }
        }
    }
}
