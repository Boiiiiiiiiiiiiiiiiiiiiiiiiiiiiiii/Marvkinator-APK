package com.example.resultprojectandstudio;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ResultActivity extends AppCompatActivity {

    private ImageView heroImage;
    private TextView heroNameText;
    private TextView topText;
    private Button btnYes, btnNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        heroImage = findViewById(R.id.heroImage);
        heroNameText = findViewById(R.id.heroName);
        topText = findViewById(R.id.topText);
        btnYes = findViewById(R.id.btnYesResult);
        btnNo = findViewById(R.id.btnNoResult);

        // Обработка ошибок, пришедших из GameActivity
        boolean showLoose = getIntent().getBooleanExtra("show_loose", false);
        String topMessage = getIntent().getStringExtra("top_message");

        if (showLoose && topMessage != null) {
            topText.setText(topMessage);
            heroImage.setImageResource(R.drawable.akinator_loose);
            heroNameText.setText(""); // нижний текст пустой
            restartAfterDelay();
            return;
        }

        // Обычный случай — загрузка героя
        int heroId = getIntent().getIntExtra("hero_id", -1);

        if (heroId != -1) {
            new FetchHeroTask(heroId).execute();
        } else {
            Toast.makeText(this, "Не удалось получить ID героя", Toast.LENGTH_SHORT).show();
        }

        btnYes.setOnClickListener(v -> {
            topText.setText("Отлично! Давай еще разок!");
            heroImage.setImageResource(R.drawable.akinator_win);
            heroNameText.setText("перезапускаем...");
            restartAfterDelay();
        });

        btnNo.setOnClickListener(v -> {
            topText.setText("Вмять! Давай еще, я точно смогу!");
            heroImage.setImageResource(R.drawable.akinator_loose);
            heroNameText.setText("перезапускаем...");
            restartAfterDelay();
        });
    }

    private void restartAfterDelay() {
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(ResultActivity.this, GameActivity.class);
            startActivity(intent);
            finish();
        }, 5000); // 5 секунд
    }

    private class FetchHeroTask extends AsyncTask<Void, Void, JSONObject> {
        private final int heroId;

        FetchHeroTask(int heroId) {
            this.heroId = heroId;
        }

        @Override
        protected JSONObject doInBackground(Void... voids) {
            try {
                URL url = new URL("https://app-a2989357-1f55-4709-adfc-df0a25cdbbd8.cleverapps.io/fetch_hero_by_id.php?id=" + heroId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();

                return new JSONObject(response.toString());

            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(JSONObject heroData) {
            if (heroData == null || heroData.has("error")) {
                Toast.makeText(ResultActivity.this, "Ошибка загрузки героя", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                String name = heroData.getString("name");
                String image_link = heroData.getString("image_link");

                heroNameText.setText(name);
                topText.setText("Я думаю что ваш персонаж это");

                Glide.with(ResultActivity.this)
                        .load(image_link)
                        .into(heroImage);

            } catch (Exception e) {
                Toast.makeText(ResultActivity.this, "Ошибка обработки данных героя", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
