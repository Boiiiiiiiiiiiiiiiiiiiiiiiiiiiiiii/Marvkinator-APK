<?php
echo "Server is running!";
?>